/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Java_Constructor_Example;

/**
 *
 * @author cef19
 */
public class Main {
    int x; // create a class attribute
    
    // create a class contructor for the Main class

    public Main(){
      x = 5; // Set the initial value for the class attribute x
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Main myObj= new Main(); // create an object of class Main (This will call the constructor)
        System.out.println(myObj.x); //Print the value of x
    }
    
}
