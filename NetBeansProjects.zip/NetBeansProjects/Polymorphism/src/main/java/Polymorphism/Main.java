/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Polymorphism;
class Animal {
void animalSound(){
     System.out.println("Animal makes a sound");
    }
}
    class Pig extends Animal{
    void animalSound(){
      System.out.println("The pig says wee wee");
    }
    }
    
    class Dog extends Animal {
     void animalSound(){
       System.out.println("The dog barks");
    }
    }
/**  
 *
 * @author cef19
 */
public class Main {
    
    public static void main(String[] args) {
        // TODO code application logic here
        Animal myAnimal= new Animal();
        Animal myPig = new Pig();
        Animal myDog = new Dog();
        
        myAnimal.animalSound();
        myPig.animalSound();
        myDog.animalSound();
    }
    
}
